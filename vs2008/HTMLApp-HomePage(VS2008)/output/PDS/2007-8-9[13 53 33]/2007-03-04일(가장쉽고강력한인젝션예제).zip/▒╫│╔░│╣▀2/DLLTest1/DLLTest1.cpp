// DLLTest1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>


int main(int argc, char* argv[])
{
	::MessageBoxA( NULL, "Hello, World!", "Test", 0 );
	return 0;
}
